---
name: 达人Brief生成
description: This skill should be used when the user needs to apply the "达人Brief生成" workflow from the AI prompt collection, especially for 将产品卖点转化为达人可执行的拍摄 brief。
agent_created: true
---

# 达人Brief生成

## 目的

用于把《AI提示词.pdf》中“达人Brief生成”相关提示词沉淀为可复用的 WorkBuddy Skill。适用于将产品卖点转化为达人可执行的拍摄 brief。

## 使用流程

1. 先确认用户要处理的对象、品类、品牌、产品、平台、目标人群、使用场景和约束条件。
2. 如用户信息不足，优先提出 3-6 个关键问题；若用户要求直接生成，则基于合理假设输出，并明确假设。
3. 读取并参考 `references/original_prompt.md` 中的原始提示词结构，不要机械照抄占位符，要结合用户实际输入改写。
4. 生成结果时保持结构化输出，优先包含：输入摘要、关键判断、正式产出、可继续迭代的方向。
5. 涉及营销、健康、美妆、食品、母婴、教育、金融等场景时，避免夸大、绝对化、医疗化、低俗化和不可证实承诺。
6. 如果用户对结果不满意，沿着“更具体、更有画面、更口语、更有传播性、更符合平台语感”的方向继续迭代。

## 默认输出结构

- **输入信息确认**：复述用户提供的核心信息和必要假设。
- **生成结果**：按任务要求输出可直接使用的内容。
- **创作逻辑**：简要说明为什么这样写。
- **优化建议**：给出 3 条可继续打磨的方向。

## 原始提示词参考

需要还原该提示词的细节时，读取：`references/original_prompt.md`。
